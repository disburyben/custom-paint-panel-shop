import { Resend } from "resend";
import { generateQuoteConfirmationHTML, generateAdminNotificationHTML } from "./emailTemplate";
import { ENV } from "./_core/env";

// Initialize Resend with API key from environment
const resend = process.env.RESEND_API_KEY ? new Resend(process.env.RESEND_API_KEY) : null;

interface QuoteConfirmationData {
  customerName: string;
  customerEmail: string;
  quoteId: number;
  vehicleType: string;
  vehicleMake?: string | null;
  vehicleModel?: string | null;
  vehicleYear?: string | null;
  serviceType: string;
  description?: string | null;
}

/**
 * Send quote confirmation email to customer
 */
export async function sendQuoteConfirmationEmail(
  data: QuoteConfirmationData
): Promise<void> {
  try {
    const emailHtml = generateQuoteConfirmationHTML(data);
    const fromEmail = process.env.ADMIN_EMAIL || "admin@casperspaintworks.com.au";

    if (resend) {
      // Send actual email via Resend
      await resend.emails.send({
        from: `Caspers Paintworks <${fromEmail}>`,
        to: data.customerEmail,
        subject: `Quote Request Received - Reference #${data.quoteId}`,
        html: emailHtml,
      });
      console.log(`✅ Quote confirmation email sent to ${data.customerEmail}`);
    } else {
      // Fallback: Log the email if Resend is not configured
      console.log("⚠️  RESEND_API_KEY not configured - Email not sent");
      console.log("=== QUOTE CONFIRMATION EMAIL ===");
      console.log(`To: ${data.customerEmail}`);
      console.log(`Subject: Quote Request Received - Reference #${data.quoteId}`);
      console.log("=== END EMAIL ===");
    }
  } catch (error) {
    console.error("Failed to send quote confirmation email:", error);
    // Don't throw - we don't want email failures to block quote submission
  }
}

interface AdminNotificationData {
  quoteId: number;
  customerName: string;
  customerEmail: string;
  customerPhone?: string | null;
  vehicleType: string;
  vehicleMake?: string | null;
  vehicleModel?: string | null;
  vehicleYear?: string | null;
  serviceType: string;
  description?: string | null;
  fileCount: number;
}

/**
 * Send admin notification email when a new quote is submitted
 */
export async function sendAdminNotificationEmail(
  data: AdminNotificationData
): Promise<void> {
  try {
    // Construct dashboard URL (use production URL or localhost for dev)
    const dashboardUrl = ENV.isProduction 
      ? "https://your-domain.com/admin" 
      : "http://localhost:3000/admin";

    const emailHtml = generateAdminNotificationHTML({
      ...data,
      submittedAt: new Date(),
      dashboardUrl,
    });

    // Get admin email from environment variable
    const adminEmail = process.env.ADMIN_EMAIL || "admin@casperspaintworks.com.au";
    const fromEmail = process.env.ADMIN_EMAIL || "admin@casperspaintworks.com.au";

    if (resend) {
      // Send actual email via Resend
      await resend.emails.send({
        from: `Caspers Paintworks <${fromEmail}>`,
        to: adminEmail,
        subject: `🚨 New Quote Request #${data.quoteId} - ${data.customerName}`,
        html: emailHtml,
      });
      console.log(`✅ Admin notification email sent to ${adminEmail}`);
    } else {
      // Fallback: Log the email if Resend is not configured
      console.log("⚠️  RESEND_API_KEY not configured - Email not sent");
      console.log("=== ADMIN NOTIFICATION EMAIL ===");
      console.log(`To: ${adminEmail}`);
      console.log(`Subject: 🚨 New Quote Request #${data.quoteId} - ${data.customerName}`);
      console.log("=== END EMAIL ===");
    }
  } catch (error) {
    console.error("Failed to send admin notification email:", error);
    // Don't throw - we don't want email failures to block quote submission
  }
}
