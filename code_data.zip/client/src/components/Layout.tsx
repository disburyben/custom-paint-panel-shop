import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Menu, X, Phone, Instagram, Facebook, Mail, ArrowRight } from "lucide-react";
import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";

export default function Layout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  // Enable smooth scrolling
  useEffect(() => {
    document.documentElement.style.scrollBehavior = "smooth";
    return () => {
      document.documentElement.style.scrollBehavior = "auto";
    };
  }, []);

  const navLinks = [
    { href: "/", label: "Home" },
    { href: "/services", label: "Services" },
    { href: "/gallery", label: "Gallery" },
    { href: "/shop", label: "Shop" },
    { href: "/about", label: "About" },
    { href: "/contact", label: "Contact" },
  ];

  return (
    <div className="min-h-screen flex flex-col bg-background text-foreground overflow-x-hidden">
      {/* Navigation */}
      <motion.header
        initial={{ y: -100 }}
        animate={{ y: 0 }}
        transition={{ duration: 0.6 }}
        className={cn(
          "fixed top-0 left-0 right-0 z-50 transition-all duration-300 border-b border-transparent",
          scrolled
            ? "bg-background/90 backdrop-blur-md border-border py-3"
            : "bg-transparent py-6"
        )}
      >
        <div className="container flex items-center justify-between">
          <Link href="/">
            <motion.div 
              className="flex items-center gap-2 cursor-pointer group"
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              <div className="w-10 h-10 bg-primary skew-x-[-10deg] flex items-center justify-center border border-primary-foreground/20 group-hover:shadow-[0_0_15px_var(--primary)] transition-shadow duration-300">
                <span className="font-heading font-bold text-2xl text-primary-foreground skew-x-[10deg]">
                  CP
                </span>
              </div>
              <img src="/images/logo-full.png" alt="Caspers Paintworks" className="h-12 w-auto object-contain" />
            </motion.div>
          </Link>

          {/* Desktop Nav */}
          <nav className="hidden md:flex items-center gap-8">
            {navLinks.map((link, index) => (
              <motion.div
                key={link.href}
                initial={{ opacity: 0, y: -20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.4, delay: index * 0.1 }}
              >
                <Link href={link.href}>
                  <span
                    className={cn(
                      "font-heading font-medium text-sm uppercase tracking-widest hover:text-primary transition-colors cursor-pointer relative group py-2",
                      location === link.href ? "text-primary" : "text-muted-foreground"
                    )}
                  >
                    {link.label}
                    <span className={cn(
                      "absolute bottom-0 left-0 w-full h-[2px] bg-primary scale-x-0 group-hover:scale-x-100 transition-transform duration-300 origin-left",
                      location === link.href && "scale-x-100"
                    )} />
                  </span>
                </Link>
              </motion.div>
            ))}
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.4, delay: 0.6 }}
            >
              <Link href="/contact">
                <motion.div
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <Button 
                    variant="default" 
                    className="group skew-x-[-10deg] font-heading uppercase tracking-wider hover:shadow-[0_0_20px_var(--primary)] transition-all duration-300 relative overflow-hidden"
                  >
                    {/* Pulse effect */}
                    <motion.span
                      className="absolute inset-0 bg-white/20"
                      animate={{ 
                        scale: [1, 1.5, 1],
                        opacity: [0.5, 0, 0.5]
                      }}
                      transition={{ 
                        duration: 2,
                        repeat: Infinity,
                        repeatDelay: 1
                      }}
                    />
                    <span className="skew-x-[10deg] flex items-center gap-2 relative z-10">
                      Get Quote
                      <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform duration-300" />
                    </span>
                  </Button>
                </motion.div>
              </Link>
            </motion.div>
          </nav>

          {/* Mobile Menu Toggle */}
          <motion.button
            className="md:hidden text-foreground"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            whileTap={{ scale: 0.9 }}
          >
            {isMobileMenuOpen ? <X /> : <Menu />}
          </motion.button>
        </div>
      </motion.header>

      {/* Mobile Menu Overlay */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div 
            initial={{ opacity: 0, x: "100%" }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: "100%" }}
            transition={{ duration: 0.3 }}
            className="fixed inset-0 z-40 bg-background/95 backdrop-blur-xl pt-24 px-6 md:hidden flex flex-col gap-6"
          >
            {navLinks.map((link, index) => (
              <motion.div
                key={link.href}
                initial={{ opacity: 0, x: 50 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.3, delay: index * 0.1 }}
              >
                <Link href={link.href}>
                  <span
                    className="font-heading text-2xl font-bold uppercase tracking-widest hover:text-primary transition-colors cursor-pointer block border-b border-border/50 pb-4"
                    onClick={() => setIsMobileMenuOpen(false)}
                  >
                    {link.label}
                  </span>
                </Link>
              </motion.div>
            ))}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: 0.6 }}
            >
              <Button className="w-full mt-4 font-heading uppercase tracking-wider" size="lg">
                Get a Free Quote
              </Button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Main Content */}
      <main className="flex-grow pt-0">
        {children}
      </main>

      {/* Footer */}
      <footer className="bg-card border-t border-border py-16 relative overflow-hidden">
        {/* Grid Background Effect */}
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#80808012_1px,transparent_1px),linear-gradient(to_bottom,#80808012_1px,transparent_1px)] bg-[size:24px_24px] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_0%,#000_70%,transparent_100%)] pointer-events-none" />
        
        <div className="container relative z-10">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
            <div className="col-span-1 md:col-span-1">
             <div className="mb-6">
                <img src="/images/logo-full.png" alt="Caspers Paintworks" className="h-16 w-auto object-contain" />
              </div>              <p className="text-muted-foreground text-sm leading-relaxed mb-6">
                Taking all Automotive Paintwork Enquiries! Premium automotive restoration and custom paint services in Adelaide.
              </p>
              <div className="flex gap-4">
                <motion.a 
                  href="https://www.instagram.com/casperspaintworks" 
                  target="_blank" 
                  rel="noopener noreferrer" 
                  className="w-10 h-10 rounded-none border border-border flex items-center justify-center hover:bg-primary hover:text-primary-foreground hover:border-primary transition-all duration-300 group"
                  whileHover={{ scale: 1.1, rotate: 5 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <Instagram className="w-5 h-5" />
                </motion.a>
                <motion.a 
                  href="#" 
                  className="w-10 h-10 rounded-none border border-border flex items-center justify-center hover:bg-primary hover:text-primary-foreground hover:border-primary transition-all duration-300 group"
                  whileHover={{ scale: 1.1, rotate: -5 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <Facebook className="w-5 h-5" />
                </motion.a>
              </div>
            </div>

            <div className="col-span-1">
              <h4 className="font-heading font-bold text-lg uppercase mb-6 text-primary">Services</h4>
              <ul className="space-y-3 text-sm text-muted-foreground">
                {["Custom Resprays", "Collision Repair", "Classic Restoration", "Detailing & Protection", "Paint Correction"].map((service) => (
                  <motion.li 
                    key={service}
                    className="hover:text-foreground transition-colors cursor-pointer"
                    whileHover={{ x: 5 }}
                  >
                    {service}
                  </motion.li>
                ))}
              </ul>
            </div>

            <div className="col-span-1">
              <h4 className="font-heading font-bold text-lg uppercase mb-6 text-primary">Contact</h4>
              <ul className="space-y-4 text-sm text-muted-foreground">
                <li className="flex items-start gap-3">
                  <Phone className="w-5 h-5 text-primary shrink-0" />
                  <span>0466 254 055</span>
                </li>
                <li className="flex items-start gap-3">
                  <Mail className="w-5 h-5 text-primary shrink-0" />
                  <span>admin@casperspaintworks.com.au</span>
                </li>
                <li className="flex items-start gap-3">
                  <div className="w-5 h-5 text-primary shrink-0 font-heading font-bold">AD</div>
                  <span>33 Ayfield Road,<br />Para Hills West, SA</span>
                </li>
              </ul>
            </div>

            <div className="col-span-1">
              <h4 className="font-heading font-bold text-lg uppercase mb-6 text-primary">Hours</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li className="flex justify-between border-b border-border/50 pb-2">
                  <span>Mon - Fri</span>
                  <span className="text-foreground font-medium">8:30 AM - 4:30 PM</span>
                </li>
                <li className="flex justify-between border-b border-border/50 pb-2">
                  <span>Saturday</span>
                  <span className="text-destructive">Closed</span>
                </li>
                <li className="flex justify-between pb-2">
                  <span>Sunday</span>
                  <span className="text-destructive">Closed</span>
                </li>
              </ul>
            </div>
          </div>

          <div className="border-t border-border pt-8 flex flex-col md:flex-row justify-between items-center gap-4 text-xs text-muted-foreground uppercase tracking-wider">
            <p>&copy; {new Date().getFullYear()} Caspers Paintworks. All rights reserved.</p>
            <div className="flex gap-6 items-center">
              <a href="#" className="hover:text-primary transition-colors">Privacy Policy</a>
              <a href="#" className="hover:text-primary transition-colors">Terms of Service</a>
              <Link href="/admin/login">
                <span className="text-muted-foreground/50 hover:text-primary transition-colors cursor-pointer text-[10px]">
                  Admin
                </span>
              </Link>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
