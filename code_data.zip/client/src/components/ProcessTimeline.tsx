import { useRef, useState, useEffect } from "react";
import { motion, useScroll, useTransform, useInView, useMotionValueEvent } from "framer-motion";
import { Wrench, Paintbrush, Sparkles, Hammer, Search } from "lucide-react";

const steps = [
  {
    id: 1,
    title: "Assessment & Stripping",
    description: "Every project begins with a forensic inspection. We strip the vehicle down to bare metal to reveal hidden rust, previous repairs, and imperfections that need addressing.",
    icon: Search,
    image: "/images/service-restoration.jpg"
  },
  {
    id: 2,
    title: "Metal Work & Fabrication",
    description: "Our master craftsmen repair rust, fabricate custom panels, and ensure body lines are better than factory. This is the foundation of a perfect finish.",
    icon: Hammer,
    image: "/images/engine-bay-prep-1.jpg"
  },
  {
    id: 3,
    title: "Preparation & Priming",
    description: "Multiple stages of blocking and priming create a glass-smooth surface. We don't rush this step—it's the secret to deep, flawless paint.",
    icon: Wrench,
    image: "/images/engine-bay-paint-1.jpg"
  },
  {
    id: 4,
    title: "Painting & Clear Coat",
    description: "Using premium Glasurit and PPG systems, we lay down base coats and high-solids clear for incredible depth and UV protection.",
    icon: Paintbrush,
    image: "/images/service-paint.jpg"
  },
  {
    id: 5,
    title: "Cut & Polish",
    description: "The final stage involves wet sanding and multi-stage polishing to remove any texture, resulting in a mirror-like 'show car' finish.",
    icon: Sparkles,
    image: "/images/feature-detail.jpg"
  }
];

// Animated counter that counts up when in view
function AnimatedNumber({ value }: { value: number }) {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true });
  const [displayValue, setDisplayValue] = useState(0);

  useEffect(() => {
    if (isInView) {
      let start = 0;
      const duration = 1000;
      const increment = value / (duration / 16);
      const timer = setInterval(() => {
        start += increment;
        if (start >= value) {
          setDisplayValue(value);
          clearInterval(timer);
        } else {
          setDisplayValue(Math.floor(start));
        }
      }, 16);
      return () => clearInterval(timer);
    }
  }, [isInView, value]);

  return <span ref={ref}>{displayValue.toString().padStart(2, '0')}</span>;
}

export default function ProcessTimeline() {
  const containerRef = useRef<HTMLDivElement>(null);
  const [activeStep, setActiveStep] = useState(0);
  
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start start", "end end"]
  });

  // Track which step is active based on scroll
  useMotionValueEvent(scrollYProgress, "change", (latest) => {
    const stepIndex = Math.min(Math.floor(latest * steps.length), steps.length - 1);
    setActiveStep(stepIndex);
  });

  const progressHeight = useTransform(scrollYProgress, [0, 1], ["0%", "100%"]);

  return (
    <div ref={containerRef} className="relative bg-black py-20">
      <div className="container mx-auto px-4">
        {/* Header with fade in */}
        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-20"
        >
          <h2 className="font-heading font-bold text-4xl md:text-5xl uppercase mb-4">The Process</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Perfection isn't an accident. It's a disciplined, multi-stage journey that transforms raw metal into automotive art.
          </p>
        </motion.div>

        <div className="relative">
          {/* Animated Vertical Progress Line */}
          <div className="absolute left-4 md:left-1/2 top-0 bottom-0 w-0.5 bg-white/10 -translate-x-1/2 hidden md:block">
            <motion.div 
              className="absolute top-0 left-0 w-full bg-primary"
              style={{ height: progressHeight }}
            />
          </div>

          <div className="space-y-24 md:space-y-40">
            {steps.map((step, index) => {
              const isEven = index % 2 === 0;
              return (
                <motion.div
                  key={step.id}
                  initial={{ opacity: 0, x: isEven ? -50 : 50 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true, margin: "-100px" }}
                  transition={{ duration: 0.7 }}
                  className={`flex flex-col md:flex-row items-center gap-8 md:gap-16 ${
                    isEven ? "md:flex-row" : "md:flex-row-reverse"
                  }`}
                >
                  {/* Image Side with staggered reveal */}
                  <motion.div 
                    className="w-full md:w-1/2 relative group"
                    initial={{ opacity: 0, scale: 0.95 }}
                    whileInView={{ opacity: 1, scale: 1 }}
                    viewport={{ once: true, margin: "-50px" }}
                    transition={{ duration: 0.6, delay: 0.2 }}
                  >
                    <motion.div 
                      className="absolute -inset-2 bg-white/5 transform rotate-2"
                      whileHover={{ rotate: 1 }}
                      transition={{ duration: 0.5 }}
                    />
                    <div className="relative aspect-video overflow-hidden border border-white/10 bg-black">
                      <motion.img
                        src={step.image}
                        alt={step.title}
                        className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-700"
                        whileHover={{ scale: 1.05 }}
                        transition={{ duration: 0.7 }}
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent opacity-60" />
                      <div className="absolute bottom-4 left-4 flex items-center gap-2">
                        <motion.div 
                          className="w-8 h-8 bg-white text-black flex items-center justify-center font-bold text-sm"
                          initial={{ scale: 0 }}
                          whileInView={{ scale: 1 }}
                          viewport={{ once: true }}
                          transition={{ duration: 0.4, delay: 0.4 }}
                        >
                          <AnimatedNumber value={step.id} />
                        </motion.div>
                        <span className="text-xs uppercase tracking-widest font-bold">Stage {step.id}</span>
                      </div>
                    </div>
                  </motion.div>

                  {/* Center Icon (Desktop) with rotation on hover */}
                  <motion.div 
                    className="hidden md:flex absolute left-1/2 -translate-x-1/2 w-12 h-12 bg-black border border-white/20 rounded-full items-center justify-center z-10"
                    initial={{ scale: 0, rotate: -180 }}
                    whileInView={{ scale: 1, rotate: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.5, delay: 0.3 }}
                    whileHover={{ scale: 1.2, rotate: 15, borderColor: "var(--primary)" }}
                  >
                    <step.icon className="w-5 h-5 text-white" />
                  </motion.div>

                  {/* Content Side with staggered text */}
                  <motion.div 
                    className={`w-full md:w-1/2 ${isEven ? "md:text-right" : "md:text-left"}`}
                    initial={{ opacity: 0, y: 30 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true, margin: "-50px" }}
                    transition={{ duration: 0.6, delay: 0.3 }}
                  >
                    <div className="flex items-center gap-3 mb-4 md:hidden">
                      <motion.div
                        whileHover={{ rotate: 15, scale: 1.1 }}
                        transition={{ duration: 0.3 }}
                      >
                        <step.icon className="w-5 h-5 text-white" />
                      </motion.div>
                      <span className="text-xs uppercase tracking-widest font-bold text-white/50">Stage 0{step.id}</span>
                    </div>
                    <h3 className="font-heading font-bold text-2xl md:text-3xl uppercase mb-4">{step.title}</h3>
                    <p className="text-muted-foreground leading-relaxed">
                      {step.description}
                    </p>
                  </motion.div>
                </motion.div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
