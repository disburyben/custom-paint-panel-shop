import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { ArrowRight, CheckCircle2, Star } from "lucide-react";
import { Link } from "wouter";
import { motion, useScroll, useTransform, useInView } from "framer-motion";
import { useRef, useEffect, useState } from "react";
import BeforeAfterSlider from "@/components/BeforeAfterSlider";
import ProcessTimeline from "@/components/ProcessTimeline";

// Animated counter component
function AnimatedCounter({ value, duration = 2 }: { value: number; duration?: number }) {
  const [count, setCount] = useState(0);
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true });

  useEffect(() => {
    if (isInView) {
      let start = 0;
      const end = value;
      const incrementTime = (duration * 1000) / end;
      const timer = setInterval(() => {
        start += 1;
        setCount(start);
        if (start === end) clearInterval(timer);
      }, incrementTime);
      return () => clearInterval(timer);
    }
  }, [isInView, value, duration]);

  return <span ref={ref}>{count.toString().padStart(2, '0')}</span>;
}

// Fade in on scroll component
function FadeInOnScroll({ children, delay = 0, direction = "up" }: { children: React.ReactNode; delay?: number; direction?: "up" | "down" | "left" | "right" }) {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-50px" });
  
  const directions = {
    up: { y: 40, x: 0 },
    down: { y: -40, x: 0 },
    left: { x: 40, y: 0 },
    right: { x: -40, y: 0 }
  };

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, ...directions[direction] }}
      animate={isInView ? { opacity: 1, x: 0, y: 0 } : {}}
      transition={{ duration: 0.7, delay }}
    >
      {children}
    </motion.div>
  );
}

export default function Home() {
  let { user, loading, error, isAuthenticated, logout } = useAuth();
  const heroRef = useRef(null);
  const { scrollYProgress } = useScroll({
    target: heroRef,
    offset: ["start start", "end start"]
  });
  
  const backgroundY = useTransform(scrollYProgress, [0, 1], ["0%", "30%"]);
  const textY = useTransform(scrollYProgress, [0, 1], ["0%", "50%"]);

  // Staggered text animation for hero
  const words = ["Precision", "Meets", "Passion"];
  
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.15,
        delayChildren: 0.3
      }
    }
  };

  const wordVariants = {
    hidden: { opacity: 0, y: 50, rotateX: -90 },
    visible: {
      opacity: 1,
      y: 0,
      rotateX: 0,
      transition: {
        duration: 0.8
      }
    }
  };

  const lineDrawVariants = {
    hidden: { scaleX: 0 },
    visible: {
      scaleX: 1,
      transition: {
        duration: 0.8
      }
    }
  };

  const fadeUpVariants = {
    hidden: { opacity: 0, y: 30 },
    visible: (delay: number) => ({
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.6,
        delay
      }
    })
  };

  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section ref={heroRef} className="relative h-screen min-h-[800px] flex items-center overflow-hidden">
        {/* Background with Parallax */}
        <motion.div 
          className="absolute inset-0 z-0"
          style={{ y: backgroundY }}
        >
          <video 
            src="/images/owner-painting-video.mp4" 
            autoPlay 
            loop 
            muted 
            playsInline
            className="w-full h-full object-cover opacity-40"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-background via-background/50 to-transparent" />
          <div className="absolute inset-0 bg-gradient-to-r from-background via-transparent to-transparent" />
          {/* Subtle moving gradient overlay */}
          <motion.div 
            className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-primary/10"
            animate={{ 
              backgroundPosition: ["0% 0%", "100% 100%"],
            }}
            transition={{ 
              duration: 20, 
              repeat: Infinity, 
              repeatType: "reverse",
              ease: "linear"
            }}
          />
        </motion.div>

        <motion.div 
          className="container relative z-10 pt-20"
          style={{ y: textY }}
        >
          <div className="max-w-3xl">
            {/* Animated line + subtitle */}
            <motion.div 
              initial="hidden"
              animate="visible"
              className="flex items-center gap-4 mb-6"
            >
              <motion.div 
                variants={lineDrawVariants}
                className="h-[2px] w-12 bg-primary origin-left"
              />
              <motion.span 
                variants={fadeUpVariants}
                custom={0.5}
                className="text-primary font-heading font-bold uppercase tracking-[0.3em] text-sm"
              >
                Premium Automotive Styling
              </motion.span>
            </motion.div>
            
            {/* Staggered word reveal */}
            <motion.h1 
              variants={containerVariants}
              initial="hidden"
              animate="visible"
              className="font-heading font-bold text-6xl md:text-8xl uppercase leading-[0.9] mb-8 text-white drop-shadow-[0_0_15px_rgba(0,0,0,0.5)]"
            >
              {words.map((word, index) => (
                <motion.span
                  key={word}
                  variants={wordVariants}
                  className={`block overflow-hidden ${index === 1 ? "text-transparent bg-clip-text bg-gradient-to-r from-primary to-white" : ""}`}
                  style={{ perspective: "1000px" }}
                >
                  {word}
                </motion.span>
              ))}
            </motion.h1>
            
            <motion.p 
              variants={fadeUpVariants}
              initial="hidden"
              animate="visible"
              custom={1.2}
              className="text-lg md:text-xl text-gray-300 mb-10 max-w-xl font-light leading-relaxed border-l-2 border-primary/50 pl-6"
            >
              Transform your vehicle into a masterpiece. We specialize in high-end custom paint, collision repair, and classic restoration with showroom-quality finishes.
            </motion.p>
            
            <motion.div 
              variants={fadeUpVariants}
              initial="hidden"
              animate="visible"
              custom={1.5}
              className="flex flex-wrap gap-6"
            >
              <Link href="/contact">
                <Button size="lg" className="group h-14 px-8 text-lg skew-x-[-10deg] hover:shadow-[0_0_30px_var(--primary)] transition-all duration-300 border-none bg-primary text-primary-foreground">
                  <span className="skew-x-[10deg] flex items-center gap-2">
                    Start Your Project 
                    <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform duration-300" />
                  </span>
                </Button>
              </Link>
              <Link href="/gallery">
                <Button variant="outline" size="lg" className="h-14 px-8 text-lg skew-x-[-10deg] border-white/20 text-white hover:bg-white/10 hover:text-white hover:border-white/50 backdrop-blur-sm">
                  <span className="skew-x-[10deg]">View Gallery</span>
                </Button>
              </Link>
            </motion.div>
          </div>
        </motion.div>

        {/* Animated Scroll Indicator */}
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 2, duration: 1 }}
          className="absolute bottom-10 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 text-white/50"
        >
          <motion.span 
            animate={{ opacity: [0.5, 1, 0.5] }}
            transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
            className="text-[10px] uppercase tracking-[0.3em] font-heading"
          >
            Scroll
          </motion.span>
          <motion.div 
            animate={{ y: [0, 8, 0] }}
            transition={{ duration: 1.5, repeat: Infinity, ease: "easeInOut" }}
            className="w-[1px] h-12 bg-gradient-to-b from-primary to-transparent"
          />
        </motion.div>
      </section>

      {/* Process Timeline */}
      <ProcessTimeline />

      {/* Why Choose Us / About Teaser */}
      <section className="py-24 bg-card relative overflow-hidden">
        {/* Decorative Elements */}
        <div className="absolute top-0 right-0 w-1/3 h-full bg-primary/5 skew-x-[-20deg] translate-x-20" />
        
        <div className="container relative z-10">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <FadeInOnScroll direction="left">
              <div className="relative">
                <div className="absolute -inset-4 border border-primary/30 translate-x-4 translate-y-4 z-0" />
                
                <div className="bg-background border border-border p-6 shadow-xl z-20 w-full max-w-[500px] mx-auto">
                  <BeforeAfterSlider 
                    beforeImage="/images/engine-bay-prep-1.jpg"
                    afterImage="/images/engine-bay-paint-1.jpg"
                    alt="Engine Bay Restoration"
                  />
                  <div className="mt-2 text-center">
                    <p className="text-[10px] uppercase tracking-widest text-muted-foreground">Drag to Compare</p>
                  </div>
                </div>
              </div>
            </FadeInOnScroll>
            
            <FadeInOnScroll direction="right" delay={0.2}>
              <div>
                <h2 className="font-heading font-bold text-4xl md:text-5xl uppercase mb-8">
                  The <span className="text-primary">Standard</span> <br />
                  We Set
                </h2>
                
                <div className="space-y-8">
                  {[
                    { title: "Factory-Match Precision", desc: "Using computerized color matching technology to ensure invisible repairs and seamless blends." },
                    { title: "Lifetime Warranty", desc: "We stand behind our craftsmanship. All paint work comes with a lifetime guarantee against peeling or fading." },
                    { title: "Eco-Friendly Systems", desc: "Utilizing advanced waterborne paint systems that reduce VOC emissions without compromising quality." }
                  ].map((item, index) => (
                    <FadeInOnScroll key={item.title} delay={0.3 + index * 0.15}>
                      <div className="flex gap-4 group">
                        <div className="w-12 h-12 bg-background border border-border flex items-center justify-center shrink-0 group-hover:border-primary group-hover:bg-primary/10 transition-all duration-300">
                          <CheckCircle2 className="w-6 h-6 text-primary" />
                        </div>
                        <div>
                          <h4 className="font-heading font-bold text-xl uppercase mb-2">{item.title}</h4>
                          <p className="text-muted-foreground text-sm">{item.desc}</p>
                        </div>
                      </div>
                    </FadeInOnScroll>
                  ))}
                </div>
                
                <FadeInOnScroll delay={0.7}>
                  <div className="mt-10">
                    <Link href="/about">
                      <Button variant="outline" className="group skew-x-[-10deg] border-primary text-primary hover:bg-primary hover:text-primary-foreground">
                        <span className="skew-x-[10deg] flex items-center gap-2">
                          More About Us
                          <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform duration-300" />
                        </span>
                      </Button>
                    </Link>
                  </div>
                </FadeInOnScroll>
              </div>
            </FadeInOnScroll>
          </div>
        </div>
      </section>

      {/* Testimonials / Trust */}
      <section className="py-20 bg-background border-y border-border/50">
        <div className="container text-center">
          <FadeInOnScroll>
            <h2 className="font-heading font-bold text-3xl uppercase mb-12 tracking-widest">Trusted By Enthusiasts</h2>
          </FadeInOnScroll>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[1, 2, 3].map((i, index) => (
              <FadeInOnScroll key={i} delay={index * 0.15}>
                <div className="bg-card p-8 border border-border relative group hover:-translate-y-2 hover:border-primary/50 transition-all duration-300">
                  <div className="flex justify-center gap-1 mb-6">
                    {[...Array(5)].map((_, idx) => (
                      <Star key={idx} className="w-4 h-4 text-primary fill-primary" />
                    ))}
                  </div>
                  <p className="text-muted-foreground italic mb-6 text-sm leading-relaxed">
                    "{i === 1 ? "Absolutely floored by the quality. The candy apple red finish on my Mustang is deeper than the ocean. Worth every penny." : 
                      i === 2 ? "They brought my grandfather's F100 back from the dead. The metal work is invisible. True artisans." : 
                      "Professional, timely, and the communication was excellent. My Tesla looks better than the day I bought it."}"
                  </p>
                  <div className="font-heading font-bold uppercase text-sm">
                    {i === 1 ? "Michael R." : i === 2 ? "David S." : "Sarah J."}
                  </div>
                  <div className="text-xs text-primary mt-1 uppercase tracking-wider">
                    {i === 1 ? "1967 Mustang Fastback" : i === 2 ? "1956 Ford F100" : "Tesla Model S"}
                  </div>
                </div>
              </FadeInOnScroll>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-32 relative overflow-hidden flex items-center justify-center">
        <div className="absolute inset-0 z-0">
          <div className="absolute inset-0 bg-primary/10" />
          <motion.div 
            className="absolute inset-0 bg-[radial-gradient(circle_at_center,var(--primary)_0%,transparent_70%)] opacity-20"
            animate={{ scale: [1, 1.1, 1] }}
            transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
          />
          {/* Grid Pattern */}
          <div className="absolute inset-0 bg-[linear-gradient(to_right,#80808012_1px,transparent_1px),linear-gradient(to_bottom,#80808012_1px,transparent_1px)] bg-[size:40px_40px]" />
        </div>
        
        <div className="container relative z-10 text-center max-w-3xl">
          <FadeInOnScroll>
            <h2 className="font-heading font-bold text-5xl md:text-7xl uppercase mb-6 leading-none">
              Ready to <span className="text-primary">Shine?</span>
            </h2>
          </FadeInOnScroll>
          <FadeInOnScroll delay={0.2}>
            <p className="text-xl text-muted-foreground mb-10 font-light">
              Book your consultation today and let's discuss how we can take your vehicle to the next level.
            </p>
          </FadeInOnScroll>
          <FadeInOnScroll delay={0.4}>
            <Link href="/contact">
              <motion.div
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.98 }}
              >
                <Button 
                  size="lg" 
                  className="group h-16 px-12 text-xl skew-x-[-10deg] shadow-[0_0_40px_var(--primary)] hover:shadow-[0_0_60px_var(--primary)] transition-all duration-300 bg-primary text-primary-foreground border-none"
                >
                  <motion.span 
                    className="skew-x-[10deg] font-bold uppercase tracking-widest flex items-center gap-3"
                    animate={{ 
                      textShadow: ["0 0 0px rgba(255,255,255,0)", "0 0 10px rgba(255,255,255,0.5)", "0 0 0px rgba(255,255,255,0)"]
                    }}
                    transition={{ duration: 2, repeat: Infinity }}
                  >
                    Get Your Free Quote
                    <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform duration-300" />
                  </motion.span>
                </Button>
              </motion.div>
            </Link>
          </FadeInOnScroll>
        </div>
      </section>
    </div>
  );
}
